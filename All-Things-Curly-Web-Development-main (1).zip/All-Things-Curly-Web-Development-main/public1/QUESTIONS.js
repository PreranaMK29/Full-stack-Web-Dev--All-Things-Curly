var questions = [
    ["I would describe my curl pattern", "Straight", "Wavy: S shaped bends", "Curly: Loose ringlets,springy", "Coily: z-shaped zig-zags","1","2","3","4"],
    ["What is the thickness of your hair", "Very fine", "Fine", "Medium", "Thick","1","2","3","4"],
    ["What is your hair porosity?", "Low", "Medium", "High","Very high", "1","2","3","4"],
    ["What is your hair elasticity", "Very low", "Low", "Medium", "High","1","2","3","4"],
    ["How often do you wash your hair", "Everyday", "2-3 times a week", "Once a week", "Once in 2 weeks","1","2","3","4"],
    ];