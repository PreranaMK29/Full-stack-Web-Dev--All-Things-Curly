# All-Things-Curly-Web-Development
'All Things Curly' is a website catered to caring for curly hair. 
Our website provides the following features:
- Hair type identification quiz: To identify the specific hair type/ pattern (Type 1,2,3 or 4)
- Articles: These articles help the user to learn about their particular hair type, and how to care for it.
- Product shopping: Shopping for products for the user's particular hair type.
With this website, we hope to make the hair care community more inclusive and accepting of en and women with curly hair.
